from pydantic import BaseModel, EmailStr
from typing import Optional

class UserCreate(BaseModel):
    email:EmailStr
    password:str
    role:str

class UserLogin(BaseModel):
    email:EmailStr
    password:str

class UserProfile(BaseModel):
    id:int
    email:EmailStr
    role:str
    signup_date:str

class UpdateUserProfile(BaseModel):
    email: Optional[EmailStr]=None
    password:Optional[str]=None
    role:Optional[str]=None

